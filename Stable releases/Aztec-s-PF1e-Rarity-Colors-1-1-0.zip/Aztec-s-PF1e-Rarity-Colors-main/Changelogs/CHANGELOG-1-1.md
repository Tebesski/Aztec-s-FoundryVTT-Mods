Version 1.1.0:

Fixes:
- Fixed text formatting in item sheet
- Minor color fixes

Extensions:
- Added Item Piles support