https://github.com/Tebesski/Aztec-s-PF1e-Rarity-Colors/assets/103367127/e5cb1977-ab7a-46da-b6da-d25f0066258b

Ease-breezy to use. Just go into your Inventory, go for your Item, click on it, go to Advanced, in the very top find Flags, add one Dictionary flag: rarity
The value determines the color:
1. common - green
2. uncommon - blue
3. rare - violet
4. legend - orange
5. dragon - yellow
6. ancient - cyan
7. demonic - purple

And remember... Have fun!

  -- Aztec
